import json
import urllib.request
import urllib.error

BASE = 'http://localhost:8080'
def call(path, payload=None, method=None):
    request = urllib.request.Request(BASE + path, data=json.dumps(payload).encode() if payload is not None else None,
        headers={'Content-Type':'application/json'}, method=method)
    try:
        with urllib.request.urlopen(request) as response:
            return response.status, json.load(response)
    except urllib.error.HTTPError as error:
        return error.code, json.load(error)

status, products = call('/api/products')
assert status == 200 and products and products[0]['stock'] > 0
p = products[0]
status, order = call('/api/orders', {'items':[{'id':p['id'],'quantity':1}]})
assert status == 200 and order['id'] > 0
status, products = call('/api/products')
assert next(x for x in products if x['id'] == p['id'])['stock'] == p['stock']-1
status, orders = call('/api/orders')
assert orders[0]['id'] == order['id'] and orders[0]['total'] == p['price']
status, _ = call('/api/orders', {'items':[{'id':p['id'],'quantity':1000}]})
assert status == 400
status, products_after = call('/api/products')
assert next(x for x in products_after if x['id'] == p['id'])['stock'] == p['stock']-1
status, _ = call('/api/products', {'name':'Тест','category':'Другое','size':'M','price':100,'stock':2,'color':'#abcdef'})
assert status == 200
status, _ = call('/api/products', {'name':'Тест','category':'Другое','size':'M','price':-1,'stock':2,'color':'#abcdef'})
assert status == 400
with urllib.request.urlopen(BASE + '/') as response:
    assert response.status == 200 and b'<div id="root">' in response.read()
print('API, order transaction, validation and frontend: OK')
